﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingSystem
{
   class Billing
   {
      float BillAmount { get; set; }

      Project Project { get; set; }

      Customer Customer { get; set; }

      float GetBillAmount(Project project)
      {
         throw new NotImplementedException();
      }

      float GetBillAmount(Customer customer)
      {
         throw new NotImplementedException();
      }
   }
}
