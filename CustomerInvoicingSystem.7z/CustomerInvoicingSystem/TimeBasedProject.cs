﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingSystem
{
   class TimeBasedProject:Project
   {
      int NoOfEmployees { get; set; }

      float HoursCharged { get; set; }

      int Rate { get; set; }

   }
}
