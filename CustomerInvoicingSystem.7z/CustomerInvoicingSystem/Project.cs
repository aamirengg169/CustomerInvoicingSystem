﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerInvoicingSystem
{
   class Project
   {
      string Name { get; set; }

      ProjectType Type { get; set; }

      int PaidAmount { get; set; }

      DateTime StartDate { get; set; }

      Customer customer { get; set; }

      enum ProjectType
      {
         TimeBased,
         MilestoneBased
      }
   }
}
